import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import StudentList from "./src/views/StudentList";
import StudentForm from "./src/views/StudentForm";
import { Button, Icon } from "react-native-elements";
import { StudentsProvider } from "./src/context/StudentContext";

const Stack = createStackNavigator();

export default function App() {
  return (
    <StudentsProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="StudentList" screenOptions={screenOptions}>
          <Stack.Screen
            name="StudentList"
            component={StudentList}
            options={({ navigation }) => {
              return {
                title: "Daftar Mahasiswa",
                headerRight: () => <Button onPress={() => navigation.navigate("StudentForm")} type="clear" icon={<Icon name="add" size={30} color="#fff" />} />,
              };
            }}
          />

          <Stack.Screen
            name="StudentForm"
            component={StudentForm}
            options={{
              title: "Mahasiswa Baru",
            }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </StudentsProvider>
  );
}

const screenOptions = {
  headerStyle: {
    backgroundColor: "#3f51b5",
  },
  headerTintColor: "#fff",
};
