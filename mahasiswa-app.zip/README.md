# crud-mobile

## Simple CRUD in react native

## Screens 


<img src='https://user-images.githubusercontent.com/60331806/113492848-15c0a100-94b1-11eb-96c9-414682116438.jpeg' width='200'>
 

<img src='https://user-images.githubusercontent.com/60331806/113492850-2113cc80-94b1-11eb-96fb-9f9ee9a980ea.jpeg' width='200'>





- Rode: 

```
yarn install
ou
npm install

e depois
expo start
```
