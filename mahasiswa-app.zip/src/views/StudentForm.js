import React, { useContext, useState, useEffect } from "react";
import RadioGroup from "react-native-radio-buttons-group";
import { Text, View, TextInput, StyleSheet, ActivityIndicator } from "react-native";
import { Button, CheckBox } from "react-native-elements";
import StudentsContext from "../context/StudentContext";
import { requestPermissionsAsync, getCurrentPositionAsync } from "expo-location";

const radioButtonsData = [
  {
    id: 1,
    label: "Laki-Laki",
    value: "Laki-Laki",
    selected: true,
  },
  {
    id: 2,
    label: "Perempuan",
    value: "Perempuan",
  },
];

export default ({ route, navigation }) => {
  const [student, setStudent] = useState(route.params ? route.params : {});
  const { dispatch } = useContext(StudentsContext);

  const [radioButtons, setRadioButtons] = useState(radioButtonsData);

  function onPressRadioButton(radioButtonsArray) {
    console.log(radioButtonsArray);
    setRadioButtons(radioButtonsArray);
  }

  const [location, setLocation] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      setLoading(true);
      let { status } = await requestPermissionsAsync();
      if (status !== "granted") {
        setErrorMsg("Permission to access location was denied");
        return;
      }

      let location = await getCurrentPositionAsync({});
      const { latitude, longitude } = location.coords;

      fetch(`https://us1.locationiq.com/v1/reverse?key=pk.5494c23e921196d5cfde092e76106498&lat=${latitude}&lon=${longitude}&format=json`)
        .then((response) => response.json())
        .then((json) => {
          setLocation(json.display_name);
          setLoading(false);
        })
        .catch((error) => {
          console.error(error);
          setLoading(false);
        });
    })();
  }, []);

  return (
    <View style={style.form}>
      <Text style={style.label}>NIM</Text>
      <TextInput style={style.input} onChangeText={(nim) => setStudent({ ...student, nim })} placeholder="NIM" value={student.nim} />

      <Text style={style.label}>Nama</Text>
      <TextInput style={style.input} onChangeText={(name) => setStudent({ ...student, name })} placeholder="Nama" value={student.name} />

      <Text style={style.label}>Alamat</Text>
      <TextInput style={style.input} onChangeText={(address) => setStudent({ ...student, address })} placeholder="Alamat" value={student.alamat} />

      <Text style={style.label}>Jenis Kelamin</Text>
      <RadioGroup style={style.radio} layout="row" radioButtons={radioButtons} onPress={onPressRadioButton} />

      <Text style={style.label}>Hobi</Text>
      <TextInput style={style.input} onChangeText={(hobby) => setStudent({ ...student, hobby })} placeholder="Hobi" value={student.hobi} />

      <Text style={style.label}>Komentar</Text>
      <TextInput style={style.input} onChangeText={(comment) => setStudent({ ...student, comment })} multiline="true" placeholder="Komentar" value={student.komentar} />

      <Text style={style.label}>Lokasi</Text>
      <TextInput style={style.input} placeholder="komentar" value={location} multiline="true" editable="false" />

      <Button
        title="SIMPAN"
        onPress={() => {
          const gender = radioButtons.find((f) => f.selected).value;

          dispatch({
            type: student.id ? "updateStudent" : "createStudent",
            payload: { ...student, location, gender },
          });
          navigation.navigate("StudentList");
        }}
      />
      {loading && (
        <View style={style.loading}>
          <ActivityIndicator size="large" />
        </View>
      )}
    </View>
  );
};

const style = StyleSheet.create({
  form: {
    padding: 24,
  },
  input: {
    height: 50,
    borderColor: "gray",
    borderWidth: 1,
    marginBottom: 10,
    paddingTop: 8,
    paddingBottom: 8,
    paddingLeft: 12,
    paddingRight: 16,
    borderRadius: 4,
  },
  label: {
    marginBottom: 12,
    fontWeight: "bold",
  },
  radio: {
    marginBottom: 12,
  },
  loading: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#000",
    opacity: 0.1,
  },
});
