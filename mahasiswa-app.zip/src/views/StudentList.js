import React, { useContext } from "react";
import { Alert, FlatList, Text, View, TouchableOpacity, StyleSheet, Card } from "react-native";
import { ListItem, Button, Icon } from "react-native-elements";
import StudentsContext from "../context/StudentContext";

export default (props) => {
  const { state, dispatch } = useContext(StudentsContext);

  function confirmDeletion(student) {
    dispatch({
      type: "deleteStudent",
      payload: student,
    });
  }

  function getStudentItem({ item: student }) {
    return (
      <View>
        <ListItem key={student.id} bottomDivider style={style.card}>
          <ListItem.Content>
            <ListItem.Subtitle>
              <Text>NIM</Text> <Text style={style.value}>{student.nim}</Text>
            </ListItem.Subtitle>
            <ListItem.Subtitle>
              <Text>Nama</Text> <Text style={style.value}>{student.name}</Text>
            </ListItem.Subtitle>
            <ListItem.Subtitle>
              <Text>Jenis Kelamin</Text> <Text style={style.value}>{student.gender}</Text>
            </ListItem.Subtitle>
            <ListItem.Subtitle>
              <Text>Alamat</Text> <Text style={style.value}>{student.address}</Text>
            </ListItem.Subtitle>
            <ListItem.Subtitle>
              <Text>Hobi</Text> <Text style={style.value}>{student.hobby}</Text>
            </ListItem.Subtitle>
            <ListItem.Subtitle>
              <Text>Komentar</Text> <Text style={style.value}>{student.comment}</Text>
            </ListItem.Subtitle>
            <ListItem.Subtitle>
              <Text>Lokasi</Text> <Text style={style.value}>{student.location}</Text>
            </ListItem.Subtitle>
          </ListItem.Content>

          <Button onPress={() => confirmDeletion(student)} type="clear" icon={<Icon name="delete" size={25} color="red" />} />
        </ListItem>
      </View>
    );
  }

  return <View style={style.container}>{state.students.length > 0 ? <FlatList keyExtractor={(student) => student.id.toString()} data={state.students} renderItem={getStudentItem} /> : <Text style={style.noData}>Tidak ada Data</Text>}</View>;
};

const style = StyleSheet.create({
  noData: {
    padding: 24,
    textAlign: "center",
    fontWeight: "bold",
    color: "#000",
  },
  value: {
    color: "#000",
    display: "block",
    marginBottom: 8,
  },
  container: {
    padding: 12,
  },
  card: {
    boxShadow: "10px 10px 17px -12px rgba(0,0,0,0.2)",
    borderRadius : 6,
    marginBottom: 8,
    display: "block"
  },
});
