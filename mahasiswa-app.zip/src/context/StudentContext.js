import React, { createContext, useReducer } from "react";
import students from "./students";

const initialState = { students };
const StudentsContext = createContext({});

const actions = {
  createStudent(state, action) {
    const student = action.payload;
    student.id = Math.random();
    return {
      ...state,
      students: [...state.students, student],
    };
  },
  updateStudent(state, action) {
    const updated = action.payload;

    return {
      ...state,
      students: state.students.map((u) => (u.id === updated.id ? updated : u)),
    };
  },
  deleteStudent(state, action) {
    const student = action.payload;
    return {
      ...state,
      students: state.students.filter((u) => u.id !== student.id),
    };
  },
};

export const StudentsProvider = (props) => {
  function reducer(state, action) {
    const fn = actions[action.type];
    return fn ? fn(state, action) : state;
  }

  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <StudentsContext.Provider
      value={{
        state,
        dispatch,
      }}
    >
      {props.children}
    </StudentsContext.Provider>
  );
};

export default StudentsContext;
