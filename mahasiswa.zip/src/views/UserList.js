import React, { useContext } from 'react';
import { Alert, FlatList, Text, View} from 'react-native'
import { ListItem, Button, Icon} from 'react-native-elements';
import UsersContext from '../context/UserContext'

export default props =>{
  const {state, dispatch} = useContext(UsersContext)

  function confirmDeletion(user){
    dispatch({
      type: 'deleteUser',
      payload: user
    })
  }

  function getUserItem({item: user}) {
    return (
    <ListItem 
    key={user.id}
    bottomDivider
    >             
      <ListItem.Content >
        <ListItem.Title >{user.nim} | {user.name}</ListItem.Title>
        <ListItem.Subtitle >Alamat: {user.alamat}</ListItem.Subtitle>
        <ListItem.Subtitle >Hobi: {user.hobi}</ListItem.Subtitle>
        <ListItem.Subtitle >Komentar: {user.komentar}</ListItem.Subtitle>
      </ListItem.Content>

      <Button
      onPress={()=> confirmDeletion(user)}
      type="clear"
      icon={<Icon name="delete" size={25} color="red"/>}/> 
    </ListItem>
    )
  }

  return (
    <FlatList
    keyExtractor={user => user.id.toString()}
    data={state.users}
    renderItem={getUserItem}
    />
  )
}