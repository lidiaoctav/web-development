import React, { useContext, useState, useEffect } from 'react';
import RadioGroup from 'react-native-radio-buttons-group';
import { Text, View, TextInput, StyleSheet } from 'react-native'
import { Button, CheckBox } from 'react-native-elements';
import UsersContext from '../context/UserContext';
import * as Location from 'expo-location';

const radioButtonsData = [{
    id: '1', 
    label: 'Laki Laki',
    value: 'Laki Laki'
  }, {
    id: '2',
    label: 'Perempuan',
    value: 'Perempuan'
  }]

export default ({route, navigation}) =>{
  const [user, setUser] = useState(route.params ? route.params: {})
  const {dispatch} = useContext(UsersContext);

  const [radioButtons, setRadioButtons] = useState(radioButtonsData)

  function onPressRadioButton(radioButtonsArray) {
      setRadioButtons(radioButtonsArray);
  }

  // const [location, setLocation] = useState(null);
  // const [errorMsg, setErrorMsg] = useState(null);

  // useEffect(() => {
  //   (async () => {
  //     let { status } = await Location.requestForegroundPermissionsAsync();
  //     if (status !== 'granted') {
  //       setErrorMsg('Permission to access location was denied');
  //       return;
  //     }

  //     let location = await Location.getCurrentPositionAsync({});
  //     setLocation(location);
  //   })();
  // }, []);

  // let text = 'Waiting..';
  // if (errorMsg) {
  //   text = errorMsg;
  // } else if (location) {
  //   text = JSON.stringify(location);
  // }
 
  return (
    <View style={style.form}>
      <Text>NIM</Text>
      <TextInput
      style={style.input}
      onChangeText={nim => setUser({...user, nim})}
      placeholder="NIM"
      value={user.nim}
      />

      <Text>Nama</Text>
      <TextInput
      style={style.input}
      onChangeText={name => setUser({...user, name})}
      placeholder="Nama"
      value={user.name}
      />

      <Text>Alamat:</Text>
      <TextInput
      style={style.input}
      onChangeText={alamat => setUser({...user, alamat})}
      placeholder="alamat"
      value={user.alamat}
      />

      <Text>Jenis kelamin:</Text>
      <RadioGroup
          radioButtons={radioButtons} 
          onPress={onPressRadioButton}
      />

      <Text>Hobi:</Text>
      <TextInput
      style={style.input}
      onChangeText={hobi => setUser({...user, hobi})}
      placeholder="hobi"
      value={user.hobi}
      />

      <Text>Komentar:</Text>
      <TextInput
      style={style.input}
      onChangeText={komentar => setUser({...user, komentar})}
      placeholder="komentar"
      value={user.komentar}
      />
 
      <Button title="Submit"
      onPress={()=>{
        dispatch({
          type: user.id ? 'updateUser' : 'createUser',
          payload: user
        })
        navigation.navigate('UserList')
      }}
      />
    </View>
  )
}


const style = StyleSheet.create({
  form: {
    padding: 12,
  
  }, 
  input: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 1,
    margin: 10,
    marginBottom: 10, padding: 10
  }
})